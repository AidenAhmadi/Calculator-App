package com.example.calculator

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.*
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {
    //Variables to store the entered numbers
    var firstNum = 0.0
    var secondNum = 0.0
    //The operator entered
    var operator = ""
    private lateinit var digitsDisplay: TextView
    //Creates the activity
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        digitsDisplay = findViewById(R.id.textView2)
        //Prepares the clear button for a context menu
        registerForContextMenu(findViewById(R.id.clear_button))
    }

    //Creates the context menu and inflates it
    override fun onCreateContextMenu(
        menu: ContextMenu?,
        v: View?,
        menuInfo: ContextMenu.ContextMenuInfo?
    ) {
        super.onCreateContextMenu(menu, v, menuInfo)
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.context_menu, menu)
    }

    //Creates an option menu
    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.subject_menu, menu)
        return true
    }

    //Starts the settings activity if the settings symbol is pressed
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == R.id.settings) {
            val intent = Intent(this, SettingsActivity::class.java)
            startActivity(intent)
            return true
        }

        return super.onOptionsItemSelected(item)
    }

    //adds a digit to the text view when a user presses a number
    fun addDigit(view: View){
        val buttonView = view as Button
        digitsDisplay.setText(digitsDisplay.text as String + buttonView.text)
        Log.d("digit", buttonView.text as String)
    }
    //Stores the operator the user entered and the number in the text field
    fun chooseOperator(view: View){
        val buttonView = view as Button

        firstNum = (digitsDisplay.text as String).toDouble()
        operator = buttonView.text as String
        digitsDisplay.setText("")
    }

    //Stores the second number in the text field and calculates the answer
    fun calculate(view: View){
        secondNum = (digitsDisplay.text as String).toDouble()
        var answer = 0.0
        if(operator == "÷" && secondNum == 0.0){
            //Displays a warning if the user divided by 0
            val zeroWarning = WarningDialogFragment()
            zeroWarning.show(supportFragmentManager, "Warning")
        }
        else {
            when (operator) {
                "+" -> answer = firstNum + secondNum
                "-" -> answer = firstNum - secondNum
                "×" -> answer = firstNum * secondNum
                "÷" -> answer = 1.0 * firstNum / secondNum
            }
            //displays the answer
            digitsDisplay.setText(answer.toString())
        }
    }
    //Clears the text fields and resets the numbers
    fun clearDigits(view: View){
        firstNum = 0.0
        secondNum = 0.0
        digitsDisplay.setText("")
    }
}