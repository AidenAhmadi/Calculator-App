package com.example.calculator

import android.app.AlertDialog
import android.app.Dialog
import android.os.Bundle
import androidx.fragment.app.DialogFragment

class WarningDialogFragment: DialogFragment() {
    //Creates a division by 0 alert dialog
    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val builder = AlertDialog.Builder(requireActivity())
        builder.setTitle("Warning")
        builder.setMessage("Can't divide by 0")
        builder.setPositiveButton("Ok", null)
        return builder.create()
    }
}